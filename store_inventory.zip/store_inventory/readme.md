**INVOICE INVENTORY**

This web application was design and developed by MGe Technologies LTD.

---
**Features
Auto genterate invoice
Store products, by category and store
Primary and Secondary stores
etc

---
**Configuration
Go to your phpMyadmin and create a database called `invoice`
Go to db directory in the root folder and import all the .sql files to the database.

In the user_table, two users are already created with different role

USERNAME        PASSWORD        ROLE
Admin           12345           Admin (ADM)
User            12345           User (USR)

Enjoy!
---
**Contact
Call: +234 802 936 6505
Website: https://techmanna.com.ng
