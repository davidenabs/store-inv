<div class="footer-bottom bg-light py-3">
        <div class="container-fluid">
            <div class="">
                <div class="col-md-5col-lg-" style="text-align: right; font-size: 13px;">
                    <p class="copyright-text pb-0 mb-0 text-muted">Copyrights © <?php echo date('Y'); ?>. All rights reserved by
                        <strong>MGe-Technologies LTD</strong> </p>
                </div>
            </div>
        </div>
     </div>
  </div>
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>